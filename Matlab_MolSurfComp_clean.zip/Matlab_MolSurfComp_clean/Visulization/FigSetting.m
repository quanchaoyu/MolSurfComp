function FigSetting

axis off;
view([86,15]);
light('position',[10,10,10]);
lighting gouraud;
axis equal;
    
end